单点登录框架（CAS）

简介：单点登录框架。整合了话单(hdfxyh)、账单(zdfxnew)、公共(common)、鱼鹰(yuying)等子项目